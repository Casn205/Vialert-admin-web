import { PlaceholderPage } from '@/shared-ui';

export default function AmbulancesPage() {
  return <PlaceholderPage titulo="Ambulancias" fase="el punto 1-C" />;
}
