import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import type { Hospital } from '@/core/domain/hospital';
import { hospitalSchema, type HospitalForm } from '@/core/schemas/hospital';
import { Button, FormField, Modal, campoClase } from '@/shared-ui';

interface Props {
  abierto: boolean;
  /** Hospital a editar; `null` para crear uno nuevo. */
  hospital: Hospital | null;
  onCerrar: () => void;
  /** Debe lanzar si falla para que el diálogo siga abierto. */
  onGuardar: (datos: HospitalForm) => Promise<void>;
}

export function HospitalFormModal({ abierto, hospital, onCerrar, onGuardar }: Props) {
  return (
    <Modal abierto={abierto} onCerrar={onCerrar} titulo={hospital ? 'Editar hospital' : 'Nuevo hospital'}>
      {/* El formulario se monta solo con el diálogo abierto: cada apertura empieza limpia. */}
      <Formulario hospital={hospital} onCerrar={onCerrar} onGuardar={onGuardar} />
    </Modal>
  );
}

function Formulario({ hospital, onCerrar, onGuardar }: Omit<Props, 'abierto'>) {
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<HospitalForm>({
    resolver: zodResolver(hospitalSchema),
    defaultValues: hospital ? { nombre: hospital.nombre, lat: hospital.lat, lng: hospital.lng } : undefined,
  });

  async function enviar(datos: HospitalForm) {
    try {
      await onGuardar(datos);
    } catch {
      /* el padre ya avisó del error; el diálogo se queda abierto */
    }
  }

  return (
    <form onSubmit={handleSubmit(enviar)} noValidate className="space-y-4">
      <FormField htmlFor="hospital-nombre" label="Nombre" error={errors.nombre?.message}>
        <input id="hospital-nombre" autoComplete="off" aria-invalid={!!errors.nombre} className={campoClase} {...register('nombre')} />
      </FormField>
      <div className="grid grid-cols-2 gap-3">
        <FormField htmlFor="hospital-lat" label="Latitud" error={errors.lat?.message} ayuda="Entre −90 y 90">
          <input id="hospital-lat" type="number" step="any" inputMode="decimal" aria-invalid={!!errors.lat} className={campoClase} {...register('lat', { valueAsNumber: true })} />
        </FormField>
        <FormField htmlFor="hospital-lng" label="Longitud" error={errors.lng?.message} ayuda="Entre −180 y 180">
          <input id="hospital-lng" type="number" step="any" inputMode="decimal" aria-invalid={!!errors.lng} className={campoClase} {...register('lng', { valueAsNumber: true })} />
        </FormField>
      </div>
      <p className="text-xs text-tinta-suave">
        Puedes copiar las coordenadas desde Google Maps (clic derecho sobre el lugar). La selección directa en el mapa llega con la Fase 2.
      </p>
      <div className="flex justify-end gap-2 pt-1">
        <Button variante="secundario" onClick={onCerrar} disabled={isSubmitting}>
          Cancelar
        </Button>
        <Button type="submit" cargando={isSubmitting}>
          {hospital ? 'Guardar cambios' : 'Crear hospital'}
        </Button>
      </div>
    </form>
  );
}
