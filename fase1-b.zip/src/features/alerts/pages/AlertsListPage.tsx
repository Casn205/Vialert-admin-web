import { PlaceholderPage } from '@/shared-ui';

export default function AlertsListPage() {
  return <PlaceholderPage titulo="Alertas" fase="la Fase 2" />;
}
