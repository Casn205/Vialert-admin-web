import { PlaceholderPage } from '@/shared-ui';

export default function AlertDetailPage() {
  return <PlaceholderPage titulo="Detalle de alerta" fase="la Fase 2" />;
}
