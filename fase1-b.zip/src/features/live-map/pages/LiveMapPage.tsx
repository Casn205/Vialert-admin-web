import { PlaceholderPage } from '@/shared-ui';

export default function LiveMapPage() {
  return <PlaceholderPage titulo="Mapa en vivo" fase="la Fase 2" />;
}
