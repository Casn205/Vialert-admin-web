# Preguntas abiertas

Anota aquí lo que no esté en el plan maestro y no tenga valor por defecto (sección 12). Formato:

- **[fecha] [punto de control]** Pregunta. Opción conservadora tomada mientras tanto.

_(sin preguntas por ahora)_
